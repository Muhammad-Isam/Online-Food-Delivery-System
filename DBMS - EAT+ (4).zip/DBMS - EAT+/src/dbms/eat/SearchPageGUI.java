/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbms.eat;

import Class.Restaurant;
import Class.User;
import java.util.ArrayList;
import javax.swing.JLabel;

/**
 *
 * @author Adil
 */
public class SearchPageGUI extends javax.swing.JFrame {

    String img = "/dbms/eat/";
//    String lbl = "Soft Swirl";
    String jpg = ".JPG";
    User u = new User();
    RestaurantGUI rg;
    Restaurant r = new Restaurant();

    public SearchPageGUI() {
        initComponents();
//        initialStage();
//        btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img+lbl+jpg))); // NOI18N

    }

    public SearchPageGUI(User u) {
        initComponents();
        initialStage();
        this.u = u;
    }

    public void initialStage() {
        btnr1.setVisible(false);
        btnr2.setVisible(false);
        btnr3.setVisible(false);
//        btnr4.setVisible(false);
        lblrname1.setVisible(false);
        lblradd1.setVisible(false);
        lblrname2.setVisible(false);
        lblradd2.setVisible(false);
        lblrname3.setVisible(false);
        lblradd3.setVisible(false);
//        lblrname4.setVisible(false);
//        lblradd4.setVisible(false);
        btnprev.setVisible(false);;
        btnnext.setVisible(false);
    }

    public String getLblradd1() {
        return lblradd1.getText();
    }

    public void setLblradd1(String lblradd1) {
        this.lblradd1.setText(lblradd1);
    }

    public String getLblradd2() {
        return lblradd2.getText();
    }

    public void setLblradd2(String lblradd2) {
        this.lblradd2.setText(lblradd2);
    }

    public String getLblradd3() {
        return lblradd3.getText();
    }

    public void setLblradd3(String lblradd3) {
        this.lblradd3.setText(lblradd3);
    }

//    public String getLblradd4() {
//        return lblradd4.getText();
//    }
//
//    public void setLblradd4(String lblradd4) {
//        this.lblradd4.setText(lblradd4);
//    }
    public void setRestaurantsData() {
        ArrayList<Restaurant> rL;
        Restaurant r;
        rL = u.getRestaurantByName(txtsearch.getText());
//        if (rL.size() == 4) {
//            r = rL.get(0);
//            lblrname1.setText(r.getrName());
//            lblradd1.setText(r.getrAddress());
//            r = rL.get(1);
//            lblrname2.setText(r.getrName());
//            lblradd2.setText(r.getrAddress());
//            r = rL.get(2);
//            lblrname3.setText(r.getrName());
//            lblradd3.setText(r.getrAddress());
//            r = rL.get(3);
//            lblrname4.setText(r.getrName());
//            lblradd4.setText(r.getrAddress());
//            btnr1.setVisible(true);
//            btnr2.setVisible(true);
//            btnr3.setVisible(true);
//            btnr4.setVisible(true);
//            lblrname1.setVisible(true);
//            lblradd1.setVisible(true);
//            lblrname2.setVisible(true);
//            lblradd2.setVisible(true);
//            lblrname3.setVisible(true);
//            lblradd3.setVisible(true);
//            lblrname4.setVisible(true);
//            lblradd4.setVisible(true);
//            btnprev.setVisible(false);
//            btnnext.setVisible(true);
//        } else 
        if (rL.size() == 3) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            r = rL.get(1);
            lblrname2.setText(r.getrName());
            lblradd2.setText(r.getrAddress());
            btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2.getText() + jpg)));
            r = rL.get(2);
            lblrname3.setText(r.getrName());
            lblradd3.setText(r.getrAddress());
            btnr3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname3.getText() + jpg)));
            btnr1.setVisible(true);
            btnr2.setVisible(true);
            btnr3.setVisible(true);
//            btnr4.setVisible(false);
            lblrname1.setVisible(true);
            lblradd1.setVisible(true);
            lblrname2.setVisible(true);
            lblradd2.setVisible(true);
            lblrname3.setVisible(true);
            lblradd3.setVisible(true);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
            btnnext.setVisible(true);
        } else if (rL.size() == 2) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            r = rL.get(1);
            lblrname2.setText(r.getrName());
            lblradd2.setText(r.getrAddress());
            btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2.getText() + jpg)));
            btnr1.setVisible(true);
            btnr2.setVisible(true);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname1.setVisible(true);
            lblrname2.setVisible(true);
            lblrname3.setVisible(false);
            lblradd1.setVisible(true);
            lblradd2.setVisible(true);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        } else if (rL.size() == 1) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            btnr1.setVisible(true);
            btnr2.setVisible(false);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname1.setVisible(true);
            lblrname2.setVisible(false);
            lblradd1.setVisible(true);
            lblradd2.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        } else if (rL.isEmpty()) {
            txtsearch.setText("Sorry no restaurants available by " + txtsearch.getText());

            btnr1.setVisible(false);
            btnr2.setVisible(false);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname1.setVisible(false);
            lblradd1.setVisible(false);
            lblrname2.setVisible(false);
            lblradd2.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        }

    }

    public void setnextRestaurantsData() {
        ArrayList<Restaurant> rL;
        Restaurant r;
        rL = u.getnextRestaurantByName(txtsearch.getText(), lblrname3.getText(), lblradd3.getText());
//        if (rL.size() == 4) {
//            r = rL.get(0);
//            lblrname1.setText(r.getrName());
//            lblradd1.setText(r.getrAddress());
//            r = rL.get(1);
//            lblrname2.setText(r.getrName());
//            lblradd2.setText(r.getrAddress());
//            r = rL.get(2);
//            lblrname3.setText(r.getrName());
//            lblradd3.setText(r.getrAddress());
//            r = rL.get(3);
//            lblrname4.setText(r.getrName());
//            lblradd4.setText(r.getrAddress());
//            btnprev.setVisible(false);
//            btnnext.setVisible(true);
//        } else 
        if (rL.size() == 3) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            r = rL.get(1);
            lblrname2.setText(r.getrName());
            lblradd2.setText(r.getrAddress());
            btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2.getText() + jpg)));
            r = rL.get(2);
            lblrname3.setText(r.getrName());
            lblradd3.setText(r.getrAddress());
            btnr3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname3.getText() + jpg)));

//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(true);
            btnnext.setVisible(true);
        } else if (rL.size() == 2) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            r = rL.get(1);
            lblrname2.setText(r.getrName());
            lblradd2.setText(r.getrAddress());
            btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2.getText() + jpg)));
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(true);
        } else if (rL.size() == 1) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));

            btnr2.setVisible(false);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname2.setVisible(false);
            lblradd2.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(true);
        } else if (rL.isEmpty()) {
            txtsearch.setText("Sorry no restaurants available by " + txtsearch.getText());

            btnr1.setVisible(false);
            btnr2.setVisible(false);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname1.setVisible(false);
            lblradd1.setVisible(false);
            lblrname2.setVisible(false);
            lblradd2.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(true);
        }

    }

    public void setprevRestaurantsData() {
        ArrayList<Restaurant> rL;
        Restaurant r;
        rL = u.getPrevRestaurantByName(txtsearch.getText(), lblrname1.getText(), lblradd1.getText());
//        if (rL.size() == 4) {
//            r = rL.get(0);
//            lblrname1.setText(r.getrName());
//            lblradd1.setText(r.getrAddress());
//            r = rL.get(1);
//            lblrname2.setText(r.getrName());
//            lblradd2.setText(r.getrAddress());
//            r = rL.get(2);
//            lblrname3.setText(r.getrName());
//            lblradd3.setText(r.getrAddress());
//            r = rL.get(3);
////            lblrname4.setText(r.getrName());
////            lblradd4.setText(r.getrAddress());
//            btnprev.setVisible(false);
//            btnnext.setVisible(true);
//        } else 
        if (rL.size() == 3) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            r = rL.get(1);
            lblrname2.setText(r.getrName());
            lblradd2.setText(r.getrAddress());
            btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2.getText() + jpg)));
            r = rL.get(2);
            lblrname3.setText(r.getrName());
            lblradd3.setText(r.getrAddress());
            btnr3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname3.getText() + jpg)));
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        } else if (rL.size() == 2) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));
            r = rL.get(1);
            lblrname2.setText(r.getrName());
            lblradd2.setText(r.getrAddress());
            btnr2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2.getText() + jpg)));
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        } else if (rL.size() == 1) {
            r = rL.get(0);
            lblrname1.setText(r.getrName());
            lblradd1.setText(r.getrAddress());
            btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1.getText() + jpg)));

            btnr2.setVisible(false);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname2.setVisible(false);
            lblradd2.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        } else if (rL.isEmpty()) {
            txtsearch.setText("Sorry no restaurants available by " + txtsearch.getText());

            btnr1.setVisible(false);
            btnr2.setVisible(false);
            btnr3.setVisible(false);
//            btnr4.setVisible(false);
            lblrname1.setVisible(false);
            lblradd1.setVisible(false);
            lblrname2.setVisible(false);
            lblradd2.setVisible(false);
            lblrname3.setVisible(false);
            lblradd3.setVisible(false);
//            lblrname4.setVisible(false);
//            lblradd4.setVisible(false);
            btnprev.setVisible(false);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        btnr1 = new javax.swing.JButton();
        btnnext = new javax.swing.JButton();
        btnprev = new javax.swing.JButton();
        lblrname1 = new javax.swing.JLabel();
        txtsearch = new javax.swing.JTextField();
        btnsearch = new javax.swing.JButton();
        lblradd1 = new javax.swing.JLabel();
        btnr3 = new javax.swing.JButton();
        btnr2 = new javax.swing.JButton();
        lblrname3 = new javax.swing.JLabel();
        lblradd3 = new javax.swing.JLabel();
        lblrname2 = new javax.swing.JLabel();
        lblradd2 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jButton11 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton21 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1366, 766));

        btnr1.setMaximumSize(new java.awt.Dimension(18, 16));
        btnr1.setMinimumSize(new java.awt.Dimension(18, 16));
        btnr1.setPreferredSize(new java.awt.Dimension(18, 16));
        btnr1.setSelected(true);
        btnr1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/dbms/eat/Kababjees Fried Chicken.JPG"))); // NOI18N
        btnr1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnr1ActionPerformed(evt);
            }
        });

        btnnext.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnnext.setForeground(new java.awt.Color(255, 51, 51));
        btnnext.setText(">");
        btnnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnextActionPerformed(evt);
            }
        });

        btnprev.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnprev.setForeground(new java.awt.Color(255, 51, 51));
        btnprev.setText("<");
        btnprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprevActionPerformed(evt);
            }
        });

        lblrname1.setText("RName");

        txtsearch.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txtsearch.setText("        Search a Restaurant by name.....");
        txtsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchMouseClicked(evt);
            }
        });
        txtsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsearchActionPerformed(evt);
            }
        });

        btnsearch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnsearch.setForeground(new java.awt.Color(255, 51, 51));
        btnsearch.setText("SEARCH");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        lblradd1.setText("RAdd");

        btnr3.setSelected(true);
        btnr3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnr3ActionPerformed(evt);
            }
        });

        btnr2.setSelected(true);
        btnr2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnr2ActionPerformed(evt);
            }
        });

        lblrname3.setText("RName");

        lblradd3.setText("RAdd");

        lblrname2.setText("RName");

        lblradd2.setText("RAdd");

        jButton4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 51, 51));
        jButton4.setText("Cart");

        jButton11.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 51, 51));
        jButton11.setText("Order History");

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dbms/eat/logo.jpg"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 51, 51));
        jLabel5.setText("SEARCH RESTAURANT");

        jButton21.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton21.setForeground(new java.awt.Color(255, 51, 51));
        jButton21.setText("Back");
        jButton21.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton21ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(txtsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 307, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(286, 286, 286))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jButton21)
                                    .addComponent(jButton11)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(jButton4)
                                        .addGap(494, 494, 494)
                                        .addComponent(btnsearch)))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnprev)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(lblrname1, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                                            .addComponent(lblradd1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(60, 60, 60)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblrname2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(lblradd2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(60, 60, 60)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(lblradd3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addComponent(lblrname3, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE))
                                        .addGap(45, 45, 45))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(btnr1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                                        .addComponent(btnr2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                                        .addComponent(btnr3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnnext))))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel5)))
                .addGap(20, 20, 20))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(30, 30, 30)
                        .addComponent(jButton11)
                        .addGap(4, 4, 4)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton4)
                            .addComponent(txtsearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnsearch)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel5)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton21)
                .addGap(75, 75, 75)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnr3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnnext)
                    .addComponent(btnr2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnr1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnprev))
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblrname3, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblrname2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblrname1, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblradd3)
                    .addComponent(lblradd2)
                    .addComponent(lblradd1))
                .addContainerGap(92, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 845, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnr2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnr2ActionPerformed
        r.setrName(lblrname2.getText());
        r.setrAddress(lblradd2.getText());
//        rg = new RestaurantGUI(u, r);
        rg = new RestaurantGUI(this, btnr2.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnr2ActionPerformed

    private void btnr3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnr3ActionPerformed
        r.setrName(lblrname3.getText());
        r.setrAddress(lblradd3.getText());
        rg = new RestaurantGUI(this, btnr3.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnr3ActionPerformed

    private void btnr1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnr1ActionPerformed
        r.setrName(lblrname1.getText());
        r.setrAddress(lblradd1.getText());
        rg = new RestaurantGUI(this, btnr1.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnr1ActionPerformed

    private void txtsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsearchActionPerformed

    private void txtsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchMouseClicked
        if (txtsearch.getText().equals("        Search a Restaurant by name.....")) {
            txtsearch.setText("");
        }
    }//GEN-LAST:event_txtsearchMouseClicked

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        setRestaurantsData();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnextActionPerformed
        setnextRestaurantsData();
    }//GEN-LAST:event_btnnextActionPerformed

    private void btnprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprevActionPerformed
        setprevRestaurantsData();
    }//GEN-LAST:event_btnprevActionPerformed

    private void jButton21ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton21ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton21ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SearchPageGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SearchPageGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SearchPageGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SearchPageGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SearchPageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnnext;
    private javax.swing.JButton btnprev;
    private javax.swing.JButton btnr1;
    private javax.swing.JButton btnr2;
    private javax.swing.JButton btnr3;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton21;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblradd1;
    private javax.swing.JLabel lblradd2;
    private javax.swing.JLabel lblradd3;
    private javax.swing.JLabel lblrname1;
    private javax.swing.JLabel lblrname2;
    private javax.swing.JLabel lblrname3;
    private javax.swing.JTextField txtsearch;
    // End of variables declaration//GEN-END:variables
}
