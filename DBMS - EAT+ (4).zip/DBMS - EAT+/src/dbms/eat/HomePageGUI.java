/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbms.eat;

import Class.Restaurant;
import Class.User;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JOptionPane;

/**
 *
 * @author Adil
 */
public class HomePageGUI extends javax.swing.JFrame {

    OrderHistoryGUI oh;
    RestaurantGUI rg;
    Restaurant r;
    ArrayList<Restaurant> rList;
    ArrayList<String> cList;
    User u = new User();
    ArrayList<String> sList;
    int h = 0;
    int j = 0;
    int l = 0;
    int o1 = 0;
    int o2 = 0;
    int o3 = 0;
    String img = "/dbms/eat/";
//    String lbl = "Soft Swirl";
    String jpg = ".JPG";

    public HomePageGUI() {
        initComponents();
        r = new Restaurant();
        cList = r.getAvailableCities();
        setComboBoxData();
        setTopPicksData();
        sList = u.getCategories();
        setCategoriesData(sList);
        rList = u.getRestaurants();
        setRestaurantsData(rList);
    }

    public HomePageGUI(User u) {
        initComponents();
        this.u = u;
        System.out.println(u);
        r = new Restaurant();
        cList = r.getAvailableCities();
        setComboBoxData();
        setTopPicksData();
        sList = u.getCategories();
        setCategoriesData(sList);
        rList = u.getRestaurants();
        setRestaurantsData(rList);

    }
    
    public void setRestaurantsData(ArrayList<Restaurant> rList) {
        this.rList = rList;
        Restaurant r;
        if (j == 2) {
            btnrprev.setVisible(true);

        } else {
            btnrprev.setVisible(false);

        }
        if (rList.size() == 3) {
            j++;
            r = rList.get(0);
            lblrnames1.setText(r.getrName());
            lblraddress1.setText(r.getrAddress());
            btnrs1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrnames1.getText() + jpg)));
            r = rList.get(1);
            lblrnames2.setText(r.getrName());
            lblraddress2.setText(r.getrAddress());
            btnrs2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrnames2.getText() + jpg)));

            r = rList.get(2);
            lblrnames3.setText(r.getrName());
            lblraddress3.setText(r.getrAddress());
            btnrs3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrnames3.getText() + jpg)));

            btnrs1.setVisible(true);
            btnrs2.setVisible(true);
            btnrs3.setVisible(true);
            lblrnames1.setVisible(true);
            lblrnames2.setVisible(true);
            lblrnames3.setVisible(true);
            lblraddress1.setVisible(true);
            lblraddress2.setVisible(true);
            lblraddress3.setVisible(true);
            btnrnext.setVisible(true);
        } else if (rList.size() == 2) {
            j++;
            r = rList.get(0);
            lblrnames1.setText(r.getrName());
            lblraddress1.setText(r.getrAddress());
            btnrs1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrnames1.getText() + jpg)));

            r = rList.get(1);
            lblrnames2.setText(r.getrName());
            lblraddress2.setText(r.getrAddress());
            btnrs2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrnames2.getText() + jpg)));

            btnrs1.setVisible(true);
            btnrs2.setVisible(true);
            btnrs3.setVisible(false);
            lblrnames1.setVisible(true);
            lblrnames2.setVisible(true);
            lblrnames3.setVisible(false);
            lblraddress1.setVisible(true);
            lblraddress2.setVisible(true);
            lblraddress3.setVisible(false);
        } else if (rList.size() == 1) {
            j++;
            r = rList.get(0);
            lblrnames1.setText(r.getrName());
            lblraddress1.setText(r.getrAddress());
            btnrs1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrnames1.getText() + jpg)));

            btnrs1.setVisible(true);
            btnrs2.setVisible(false);
            btnrs3.setVisible(false);
            lblrnames1.setVisible(true);
            lblrnames2.setVisible(false);
            lblrnames3.setVisible(false);
            lblraddress1.setVisible(true);
            lblraddress2.setVisible(false);
            lblraddress3.setVisible(false);
        } else if (rList.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Restaurants Available!");
        }
    }

    public void setCategoriesData(ArrayList<String> sList) {
        this.sList = sList;
        String s;
        if (h == 2) {
            btncprev.setVisible(true);

        } else {
            btncprev.setVisible(false);

        }
        if (sList.size() == 3) {
            s = sList.get(0);
            lblcat1.setText(s);
            s = sList.get(1);
            lblcat2.setText(s);
            s = sList.get(2);
            lblcat3.setText(s);

            btncat1.setVisible(true);
            btncat2.setVisible(true);
            btncat3.setVisible(true);
            btncat1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblcat1.getText() + jpg)));
            btncat2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblcat2.getText() + jpg)));
            btncat3.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblcat3.getText() + jpg)));

            lblcat1.setVisible(true);
            lblcat2.setVisible(true);
            lblcat3.setVisible(true);
            btncnext.setVisible(true);
            btncprev.setVisible(false);
            h++;
        } else if (sList.size() == 2) {
            s = sList.get(0);
            lblcat1.setText(s);
            s = sList.get(1);
            lblcat2.setText(s);

            btncat1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblcat1.getText() + jpg)));
            btncat2.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblcat2.getText() + jpg)));
            btncat1.setVisible(true);
            btncat2.setVisible(true);
            btncat3.setVisible(false);
            lblcat1.setVisible(true);
            lblcat2.setVisible(true);
            lblcat3.setVisible(false);
            btncnext.setVisible(false);
            btncprev.setVisible(false);
            h++;

        } else if (sList.size() == 1) {
            s = sList.get(0);
            lblcat1.setText(s);
            btncat1.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblcat1.getText() + jpg)));

            btncat1.setVisible(true);
            btncat2.setVisible(false);
            btncat3.setVisible(false);
            lblcat1.setVisible(true);
            lblcat2.setVisible(false);
            lblcat3.setVisible(false);
            btncnext.setVisible(false);
            btncprev.setVisible(false);
            h++;

        }
    }

    public void setTopPicksData() {
        ArrayList<Restaurant> rL;
        Restaurant r;
        rL = u.getTopPicks();
        if (rL.size() == 3) {
            r = rL.get(0);
            lblrname1t.setText(r.getrName());
            lblradd1t.setText(r.getrAddress());
            r = rL.get(1);
            lblrname2t.setText(r.getrName());
            lblradd2t.setText(r.getrAddress());
            r = rL.get(2);
            lblrname3t.setText(r.getrName());
            lblradd3t.setText(r.getrAddress());
            lblrname1t.setVisible(true);
            lblrname2t.setVisible(true);
            lblrname3t.setVisible(true);
            btnr1t.setVisible(true);
            btnr2t.setVisible(true);
            btnr3t.setVisible(true);
            lblradd1t.setVisible(true);
            lblradd2t.setVisible(true);
            lblradd3t.setVisible(true);
            btnr1t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1t.getText() + jpg)));
            btnr2t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2t.getText() + jpg)));
            btnr3t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname3t.getText() + jpg)));
        } else if (rL.size() == 2) {
            r = rL.get(0);
            lblrname1t.setText(r.getrName());
            lblradd1t.setText(r.getrAddress());
            r = rL.get(1);
            lblrname2t.setText(r.getrName());
            lblradd2t.setText(r.getrAddress());

            lblrname1t.setVisible(true);
            lblrname2t.setVisible(true);
            lblrname3t.setVisible(false);
            btnr1t.setVisible(true);
            btnr2t.setVisible(true);
            btnr3t.setVisible(false);
            lblradd1t.setVisible(true);
            lblradd2t.setVisible(true);
            lblradd3t.setVisible(false);
            btnr1t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1t.getText() + jpg)));
            btnr2t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname2t.getText() + jpg)));
        } else if (rL.size() == 1) {
            r = rL.get(0);
            lblrname1t.setText(r.getrName());
            lblradd1t.setText(r.getrAddress());

            lblrname1t.setVisible(true);
            lblrname2t.setVisible(false);
            lblrname3t.setVisible(false);
            btnr1t.setVisible(true);
            btnr2t.setVisible(false);
            btnr3t.setVisible(false);
            lblradd1t.setVisible(true);
            lblradd2t.setVisible(false);
            lblradd3t.setVisible(false);
            btnr1t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource(img + lblrname1t.getText() + jpg)));
            
        }

    }

    public Icon getBtnr1t() {
        return btnr1t.getIcon();
    }


    public Icon getBtnr2t() {
       return btnr2t.getIcon();
    }

    public Icon getBtnr3t() {
       return btnr3t.getIcon();
    }

    public Icon getBtnrs1() {
        return btnrs1.getIcon();
    }



    public Icon getBtnrs2() {
        return btnrs2.getIcon();
    }

    public Icon getBtnrs3() {
        return btnrs3.getIcon();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jButton4 = new javax.swing.JButton();
        btnsearch = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        cb_cityList = new javax.swing.JComboBox<>();
        btnfindrestaurant = new javax.swing.JButton();
        btncnext = new javax.swing.JButton();
        btnrprev = new javax.swing.JButton();
        lblcat1 = new javax.swing.JLabel();
        lblcat2 = new javax.swing.JLabel();
        lblcat3 = new javax.swing.JLabel();
        lblrname3t = new javax.swing.JLabel();
        lblrname1t = new javax.swing.JLabel();
        lblrname2t = new javax.swing.JLabel();
        lblrnames3 = new javax.swing.JLabel();
        btnrnext = new javax.swing.JButton();
        btncprev = new javax.swing.JButton();
        lblrnames1 = new javax.swing.JLabel();
        lblrnames2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        btnr2t = new javax.swing.JButton();
        btnr3t = new javax.swing.JButton();
        btncat1 = new javax.swing.JButton();
        btncat2 = new javax.swing.JButton();
        btncat3 = new javax.swing.JButton();
        btnrs2 = new javax.swing.JButton();
        btnr1t = new javax.swing.JButton();
        btnrs3 = new javax.swing.JButton();
        btnrs1 = new javax.swing.JButton();
        lblradd1t = new javax.swing.JLabel();
        lblradd2t = new javax.swing.JLabel();
        lblradd3t = new javax.swing.JLabel();
        lblraddress1 = new javax.swing.JLabel();
        lblraddress2 = new javax.swing.JLabel();
        lblraddress3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setPreferredSize(new java.awt.Dimension(1366, 766));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        jButton4.setText("Cart");

        btnsearch.setText("Search");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        jButton3.setText("OrderHistory");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        cb_cityList.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cb_cityListItemStateChanged(evt);
            }
        });

        btnfindrestaurant.setText("Find Restaurants");
        btnfindrestaurant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfindrestaurantActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnsearch)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(cb_cityList, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(btnfindrestaurant)
                                .addGap(161, 161, 161)
                                .addComponent(jButton4)))
                        .addGap(60, 60, 60))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addComponent(jButton3)
                        .addGap(42, 42, 42))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(28, Short.MAX_VALUE)
                .addComponent(btnsearch)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton4)
                    .addComponent(cb_cityList, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnfindrestaurant))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3)
                .addGap(16, 16, 16))
        );

        btncnext.setText(">");
        btncnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncnextActionPerformed(evt);
            }
        });

        btnrprev.setText("<");
        btnrprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrprevActionPerformed(evt);
            }
        });

        lblcat1.setText("jLabel1");

        lblcat2.setText("jLabel2");

        lblcat3.setText("jLabel3");

        lblrname3t.setText("jLabel3");

        lblrname1t.setText("jLabel1");

        lblrname2t.setText("jLabel2");

        lblrnames3.setText("jLabel3");

        btnrnext.setText(">");
        btnrnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrnextActionPerformed(evt);
            }
        });

        btncprev.setText("<");
        btncprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncprevActionPerformed(evt);
            }
        });

        lblrnames1.setText("jLabel1");

        lblrnames2.setText("jLabel2");

        jLabel13.setText("Top Picks");

        jLabel14.setText("Categories");

        jLabel15.setText("Restaurants");

        btnr2t.setSelected(true);
        btnr2t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnr2tActionPerformed(evt);
            }
        });

        btnr3t.setSelected(true);
        btnr3t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnr3tActionPerformed(evt);
            }
        });

        btncat1.setText("R1");
        btncat1.setSelected(true);
        btncat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncat1ActionPerformed(evt);
            }
        });

        btncat2.setText("R1");
        btncat2.setSelected(true);
        btncat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncat2ActionPerformed(evt);
            }
        });

        btncat3.setText("R1");
        btncat3.setSelected(true);
        btncat3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncat3ActionPerformed(evt);
            }
        });

        btnrs2.setText("R1");
        btnrs2.setSelected(true);
        btnrs2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrs2ActionPerformed(evt);
            }
        });

        btnr1t.setSelected(true);
        btnr1t.setSelectedIcon(new javax.swing.ImageIcon(getClass().getResource("/dbms/eat/Bistro.JPG"))); // NOI18N
        btnr1t.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnr1tActionPerformed(evt);
            }
        });

        btnrs3.setText("R1");
        btnrs3.setSelected(true);
        btnrs3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrs3ActionPerformed(evt);
            }
        });

        btnrs1.setText("R1");
        btnrs1.setSelected(true);
        btnrs1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnrs1ActionPerformed(evt);
            }
        });

        lblradd1t.setText("RAdd");

        lblradd2t.setText("jLabel2");

        lblradd3t.setText("jLabel2");

        lblraddress1.setText("RAdd");

        lblraddress2.setText("RAdd");

        lblraddress3.setText("RAdd");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btncat2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblcat2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnrs2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblrnames2, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(btncat1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblcat1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel2Layout.createSequentialGroup()
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(lblrname1t, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(btnr1t, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(lblradd1t, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(49, 49, 49)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(btnr2t, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblrname2t, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addComponent(lblradd2t, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(53, 53, 53)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addComponent(btnrs3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnrnext))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(btnr3t, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(btncat3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblrname3t, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(lblradd3t, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btncnext)))
                                .addGap(35, 35, 35))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblcat3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblrnames3, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(456, 456, 456)
                        .addComponent(lblraddress3, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(366, 366, 366)
                        .addComponent(jLabel15))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(292, 292, 292)
                        .addComponent(jLabel14)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(btncprev)
                .addGap(53, 53, 53)
                .addComponent(jLabel13)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnrprev)
                        .addGap(67, 67, 67)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnrs1, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblrnames1, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addContainerGap(63, Short.MAX_VALUE)
                        .addComponent(lblraddress2, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblraddress1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(326, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel13)
                .addGap(45, 45, 45)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnr2t, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnr3t, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnr1t, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(17, 17, 17)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblrname3t)
                    .addComponent(lblrname2t)
                    .addComponent(lblrname1t))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblradd1t)
                    .addComponent(lblradd2t)
                    .addComponent(lblradd3t))
                .addGap(19, 19, 19)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btncat1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btncat2, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btncat3, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btncnext)
                    .addComponent(btncprev))
                .addGap(32, 32, 32)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblcat1)
                    .addComponent(lblcat2)
                    .addComponent(lblcat3))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnrnext)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 52, Short.MAX_VALUE)
                        .addComponent(jLabel15)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(btnrs1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnrs2, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnrs3, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnrprev)
                                .addGap(41, 41, 41)))
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblrnames3)
                                .addComponent(lblrnames1))
                            .addComponent(lblrnames2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblraddress1)
                            .addComponent(lblraddress2)
                            .addComponent(lblraddress3))
                        .addGap(121, 121, 121))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 857, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 1123, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnfindrestaurantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfindrestaurantActionPerformed

    }//GEN-LAST:event_btnfindrestaurantActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        oh = new OrderHistoryGUI(this, u);
        this.setVisible(false);
        oh.setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        this.setVisible(false);
        SearchPageGUI sg = new SearchPageGUI(u);
        sg.setVisible(true);
    }//GEN-LAST:event_btnsearchActionPerformed

    private void btnr2tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnr2tActionPerformed
        r.setrName(lblrname2t.getText());
        r.setrAddress(lblradd2t.getText());
        rg = new RestaurantGUI(this, btnr2t.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnr2tActionPerformed

    private void btnr3tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnr3tActionPerformed
        r.setrName(lblrname3t.getText());
        r.setrAddress(lblradd3t.getText());
        rg = new RestaurantGUI(this, btnr3t.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnr3tActionPerformed

    private void btncat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncat1ActionPerformed
        setRestaurantsData(u.getRestByCatCity(cb_cityList.getSelectedItem().toString(), lblcat1.getText()));
        btncat2.setVisible(false);
        btncat3.setVisible(false);
        lblcat2.setVisible(false);
        lblcat3.setVisible(false);
        o1 = 1;
    }//GEN-LAST:event_btncat1ActionPerformed

    private void btncat2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncat2ActionPerformed
        setRestaurantsData(u.getRestByCatCity(cb_cityList.getSelectedItem().toString(), lblcat2.getText()));
        btncat1.setVisible(false);
        btncat3.setVisible(false);
        lblcat1.setVisible(false);
        lblcat3.setVisible(false);
        o2 = 1;

    }//GEN-LAST:event_btncat2ActionPerformed

    private void btncat3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncat3ActionPerformed
        setRestaurantsData(u.getRestByCatCity(cb_cityList.getSelectedItem().toString(), lblcat3.getText()));
        btncat1.setVisible(false);
        btncat2.setVisible(false);
        lblcat1.setVisible(false);
        lblcat2.setVisible(false);
        o3 = 1;

    }//GEN-LAST:event_btncat3ActionPerformed

    private void btnrs2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrs2ActionPerformed
        r.setrName(lblrnames2.getText());
        r.setrAddress(lblraddress2.getText());
        rg = new RestaurantGUI(this, btnrs2.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnrs2ActionPerformed

    private void btnr1tActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnr1tActionPerformed
        r.setrName(lblrname1t.getText());
        r.setrAddress(lblradd1t.getText());
        rg = new RestaurantGUI(this, btnr1t.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnr1tActionPerformed

    private void btnrs3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrs3ActionPerformed
        r.setrName(lblrnames3.getText());
        r.setrAddress(lblraddress3.getText());
        rg = new RestaurantGUI(this, btnrs3.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnrs3ActionPerformed

    private void btnrs1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrs1ActionPerformed
        r.setrName(lblrnames1.getText());
        r.setrAddress(lblraddress1.getText());
        rg = new RestaurantGUI(this, btnrs1.getSelectedIcon(), u, r);
        this.setVisible(false);
        rg.setVisible(true);
    }//GEN-LAST:event_btnrs1ActionPerformed

    private void btncnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncnextActionPerformed
        setCategoriesData(u.getNextCategory(lblcat3.getText()));
        btncprev.setVisible(true);
    }//GEN-LAST:event_btncnextActionPerformed

    private void btncprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncprevActionPerformed
        if (o1 == 1) {
            setRestaurantsData(u.getPrevResByCatCity(cb_cityList.getSelectedItem().toString(),
                    lblcat1.getText(), lblrnames1.getText(), lblraddress1.getText()));
        } else if (o2 == 1) {
            setRestaurantsData(u.getPrevResByCatCity(cb_cityList.getSelectedItem().toString(),
                    lblcat2.getText(), lblrnames1.getText(), lblraddress1.getText()));

        } else if (o3 == 1) {
            setRestaurantsData(u.getPrevResByCatCity(cb_cityList.getSelectedItem().toString(),
                    lblcat3.getText(), lblrnames1.getText(), lblraddress1.getText()));

        } else {
            setCategoriesData(u.getPrevCategory(lblcat1.getText()));
        }
    }//GEN-LAST:event_btncprevActionPerformed

    private void btnrnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrnextActionPerformed
//        if (l == 0) {
        //            System.out.println("here");
        //            setRestaurantsData(u.getNextRestaurants(lblrnames3.getText(), lblraddress3.getText()));
        //        } 
        //else if (l > 0) {
        if (o1 == 1) {
            setRestaurantsData(u.getNextResByCatCity(cb_cityList.getSelectedItem().toString(),
                    lblcat1.getText(), lblrnames3.getText(), lblraddress3.getText()));
        } else if (o2 == 1) {
            setRestaurantsData(u.getNextResByCatCity(cb_cityList.getSelectedItem().toString(),
                    lblcat2.getText(), lblrnames3.getText(), lblraddress3.getText()));

        } else if (o3 == 1) {
            setRestaurantsData(u.getNextResByCatCity(cb_cityList.getSelectedItem().toString(),
                    lblcat3.getText(), lblrnames3.getText(), lblraddress3.getText()));

        } else {
            setRestaurantsData(u.nextSearchRestByCity(cb_cityList.getSelectedItem().toString(),
                    lblrnames3.getText(), lblraddress3.getText()));
//        }
        }
    }//GEN-LAST:event_btnrnextActionPerformed

    private void btnrprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnrprevActionPerformed
//        if (l == 0) {
//            setRestaurantsData(u.getPrevRestaurants(lblrnames1.getText(), lblraddress1.getText()));
//        } else if (l > 0) {
        setRestaurantsData(u.prevSearchRestByCity(cb_cityList.getSelectedItem().toString(),
                lblrnames1.getText(), lblraddress1.getText()));
//        }
    }//GEN-LAST:event_btnrprevActionPerformed

    private void cb_cityListItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cb_cityListItemStateChanged

        setRestaurantsData(u.searchRestaurantbyCity(cb_cityList.getSelectedItem().toString()));
        setCategoriesData(u.getCategories());
        l = 1;

    }//GEN-LAST:event_cb_cityListItemStateChanged

    /**
     * @param args the command line arguments
     */
    public void setComboBoxData() {
        for (int i = 0; i < cList.size(); i++) {

            cb_cityList.addItem(cList.get(i).toString());
        }

    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomePageGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomePageGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomePageGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomePageGUI.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomePageGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncat1;
    private javax.swing.JButton btncat2;
    private javax.swing.JButton btncat3;
    private javax.swing.JButton btncnext;
    private javax.swing.JButton btncprev;
    private javax.swing.JButton btnfindrestaurant;
    private javax.swing.JButton btnr1t;
    private javax.swing.JButton btnr2t;
    private javax.swing.JButton btnr3t;
    private javax.swing.JButton btnrnext;
    private javax.swing.JButton btnrprev;
    private javax.swing.JButton btnrs1;
    private javax.swing.JButton btnrs2;
    private javax.swing.JButton btnrs3;
    private javax.swing.JButton btnsearch;
    private javax.swing.JComboBox<String> cb_cityList;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel lblcat1;
    private javax.swing.JLabel lblcat2;
    private javax.swing.JLabel lblcat3;
    private javax.swing.JLabel lblradd1t;
    private javax.swing.JLabel lblradd2t;
    private javax.swing.JLabel lblradd3t;
    private javax.swing.JLabel lblraddress1;
    private javax.swing.JLabel lblraddress2;
    private javax.swing.JLabel lblraddress3;
    private javax.swing.JLabel lblrname1t;
    private javax.swing.JLabel lblrname2t;
    private javax.swing.JLabel lblrname3t;
    private javax.swing.JLabel lblrnames1;
    private javax.swing.JLabel lblrnames2;
    private javax.swing.JLabel lblrnames3;
    // End of variables declaration//GEN-END:variables
}
