/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package dbms.eat;

import Class.Menu;
import Class.Restaurant;
import Class.User;
import java.util.ArrayList;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Adil
 */
public class RestaurantGUI extends javax.swing.JFrame {

    User u = new User();
    Restaurant r = new Restaurant();
    SearchPageGUI sp;
    HomePageGUI hp;
    ArrayList<Menu> mList;
    ArrayList<Menu> cartList = new ArrayList<>();
    OrderHistoryGUI oh;
    public RestaurantGUI() {
        initComponents();
    }

    public RestaurantGUI(User u, Restaurant r) {
        initComponents();
        this.u = u;
        this.r = r;
        setData();
    }

//    public RestaurantGUI(SearchPageGUI sp, User u, Restaurant r) {
//        initComponents();
//        this.u = u;
//        this.r = r;
//        this.sp = sp;
//        setInitialVisibility();
//        setData();
//    }
    
//      public RestaurantGUI(HomePageGUI hp, User u, Restaurant r) {
//        initComponents();
//        this.u = u;
//        this.r = r;
//        this.hp = hp;
//        setInitialVisibility();
//        setData();
//    }
//    
           public RestaurantGUI(HomePageGUI hp, Icon i, User u, Restaurant r) {
        initComponents();
        this.u = u;
        this.r = r;
        this.hp = hp;
        lblrpic.setIcon(i);
        setInitialVisibility();
        setData();
    }
    
           public RestaurantGUI(SearchPageGUI sp, Icon i, User u, Restaurant r) {
        initComponents();
        this.u = u;
        this.r = r;
        this.sp = sp;
        lblrpic.setIcon(i);
        setInitialVisibility();
        setData();
    }    
           
      
    public void setData() {
//        lblrpic.setIcon();
        lblrname.setText(r.getrName());
        lblradd.setText(r.getrAddress());
        lblrating.setText(String.valueOf(u.getRestaurantRating(lblrname.getText(), lblradd.getText())));
        setRestaurantMenuData();
    }
    
    public void setInitialVisibility()
    {
        btncart1.setVisible(false);
        btncart2.setVisible(false);
        btncart3.setVisible(false);
        btnn1.setVisible(false);
        btnn2.setVisible(false);
        btnn3.setVisible(false);
        btnp1.setVisible(false);
        btnp2.setVisible(false);
        btnp3.setVisible(false);
                    btncart1.setVisible(false);
            lblmname1.setVisible(false);
            lblmprice1.setVisible(false);
            lblmdesc1.setVisible(false);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
    }

    public String getLblradd() {
        return lblradd.getText();
    }

    public void setLblradd(String lblradd) {
        this.lblradd.setText(lblradd);
    }
    
    
    
    public String getLblrname() {
        return lblrname.getText();
    }

    public void setLblrname(String lblrname) {
        this.lblrname.setText(lblrname);
    }

    public void setRestaurantMenuData() {
        Menu m;
        lblq1.setVisible((false));
        lblq2.setVisible((false));
        lblq3.setVisible((false));
        mList = u.getRestaurantMenu(lblrname.getText(), lblradd.getText());
        if (mList.size() == 3) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));
            m = mList.get(2);
            lblmname3.setText(m.getiName());
            lblmdesc3.setText(m.getiDescription());
            lblmprice3.setText(String.valueOf(m.getiPrice()));

            lblmpic1.setVisible(true);
            lblmpic2.setVisible(true);
            lblmpic3.setVisible(true);
            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            btncart2.setVisible(true);
            lblmname3.setVisible(true);
            lblmprice3.setVisible(true);
            lblmdesc3.setVisible(true);
            btncart3.setVisible(true);
            btnn1.setVisible(true);
            btnn2.setVisible(true);
            btnn3.setVisible(true);
            btnp1.setVisible(true);
            btnp2.setVisible(true);
            btnp3.setVisible(true);
            btnprev.setVisible(false);
            btnnext.setVisible(true);
        } else if (mList.size() == 2) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));

            lblmpic1.setVisible(true);
            lblmpic2.setVisible(true);
            lblmpic3.setVisible(false);
            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(true);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
            btnn1.setVisible(true);
            btnn2.setVisible(true);
            btnp1.setVisible(true);
            btnp2.setVisible(true);

        } else if (mList.size() == 1) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));

            btnn1.setVisible(true);
            btnn2.setVisible(true);
            btnp1.setVisible(true);
            btnp2.setVisible(true);
            lblmpic1.setVisible(true);
            lblmpic2.setVisible(false);
            lblmpic3.setVisible(false);
            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        } else if (mList.isEmpty()) {
            txtsearch.setText("Sorry no restaurants items available");

            lblmpic1.setVisible(false);
            lblmpic2.setVisible(false);
            lblmpic3.setVisible(false);
            btncart1.setVisible(false);
            lblmname1.setVisible(false);
            lblmprice1.setVisible(false);
            lblmdesc1.setVisible(false);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        }

    }

     public void setSearchMenuData() {
        Menu m;
        lblq1.setVisible((false));
        lblq2.setVisible((false));
        lblq3.setVisible((false));
        mList = u.searchItem(txtsearch.getText(),lblrname.getText(), lblradd.getText());
         System.out.println(mList.size());
        if (mList.size() == 3) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));
            m = mList.get(2);
            lblmname3.setText(m.getiName());
            lblmdesc3.setText(m.getiDescription());
            lblmprice3.setText(String.valueOf(m.getiPrice()));

            lblmpic1.setVisible(true);
            lblmpic2.setVisible(true);
            lblmpic3.setVisible(true);
            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            btncart2.setVisible(true);
            lblmname3.setVisible(true);
            lblmprice3.setVisible(true);
            lblmdesc3.setVisible(true);
            btncart3.setVisible(true);
            btnn1.setVisible(true);
            btnn2.setVisible(true);
            btnn3.setVisible(true);
            btnp1.setVisible(true);
            btnp2.setVisible(true);
            btnp3.setVisible(true);
            btnprev.setVisible(false);
            btnnext.setVisible(true);
        } else if (mList.size() == 2) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));

            lblmpic1.setVisible(true);
            lblmpic2.setVisible(true);
            lblmpic3.setVisible(false);
            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(true);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
            btnn1.setVisible(true);
            btnn2.setVisible(true);
            btnp1.setVisible(true);
            btnp2.setVisible(true);

        } else if (mList.size() == 1) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));

            btnn1.setVisible(true);
            btnn2.setVisible(true);
            btnp1.setVisible(true);
            btnp2.setVisible(true);
            lblmpic1.setVisible(true);
            lblmpic2.setVisible(false);
            lblmpic3.setVisible(false);
            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        } else if (mList.isEmpty()) {
            txtsearch.setText("Sorry no restaurants items available");

            lblmpic1.setVisible(false);
            lblmpic2.setVisible(false);
            lblmpic3.setVisible(false);
            btncart1.setVisible(false);
            lblmname1.setVisible(false);
            lblmprice1.setVisible(false);
            lblmdesc1.setVisible(false);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        }

    }
    
   public void setPrevMenuData()
   {
       Menu m;
        lblq1.setVisible((false));
        lblq2.setVisible((false));
        lblq3.setVisible((false));
        mList = u.getprevRestaurantMenu(lblmname3.getText(), lblrname.getText(), lblradd.getText());
        if (mList.size() == 3) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));
            m = mList.get(2);
            lblmname3.setText(m.getiName());
            lblmdesc3.setText(m.getiDescription());
            lblmprice3.setText(String.valueOf(m.getiPrice()));

            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            btncart2.setVisible(true);
            lblmname3.setVisible(true);
            lblmprice3.setVisible(true);
            lblmdesc3.setVisible(true);
            btncart3.setVisible(true);

            btnprev.setVisible(false);
            btnnext.setVisible(true);
        } else if (mList.size() == 2) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));

            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            lblmname3.setVisible(true);
            lblmprice3.setVisible(true);
            lblmdesc3.setVisible(true);
            btncart2.setVisible(true);
            btnnext.setVisible(false);
            btnprev.setVisible(false);

        } else if (mList.size() == 1) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));

            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        } else if (mList.isEmpty()) {
            txtsearch.setText("Sorry no restaurants items available");

            btncart1.setVisible(false);
            lblmname1.setVisible(false);
            lblmprice1.setVisible(false);
            lblmdesc1.setVisible(false);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        }

   }
    
    public void setNextMenuData() {
        Menu m;
        lblq1.setVisible((false));
        lblq2.setVisible((false));
        lblq3.setVisible((false));
        mList = u.getnextRestaurantMenu(lblmname3.getText(), lblrname.getText(), lblradd.getText());
        if (mList.size() == 3) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));
            m = mList.get(2);
            lblmname3.setText(m.getiName());
            lblmdesc3.setText(m.getiDescription());
            lblmprice3.setText(String.valueOf(m.getiPrice()));

            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            btncart2.setVisible(true);
            lblmname3.setVisible(true);
            lblmprice3.setVisible(true);
            lblmdesc3.setVisible(true);
            btncart3.setVisible(true);

            btnprev.setVisible(false);
            btnnext.setVisible(true);
        } else if (mList.size() == 2) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));
            m = mList.get(1);
            lblmname2.setText(m.getiName());
            lblmdesc2.setText(m.getiDescription());
            lblmprice2.setText(String.valueOf(m.getiPrice()));

            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(true);
            lblmprice2.setVisible(true);
            lblmdesc2.setVisible(true);
            lblmname3.setVisible(true);
            lblmprice3.setVisible(true);
            lblmdesc3.setVisible(true);
            btncart2.setVisible(true);
            btnnext.setVisible(false);
            btnprev.setVisible(false);

        } else if (mList.size() == 1) {
            m = mList.get(0);
            lblmname1.setText(m.getiName());
            lblmdesc1.setText(m.getiDescription());
            lblmprice1.setText(String.valueOf(m.getiPrice()));

            btncart1.setVisible(true);
            lblmname1.setVisible(true);
            lblmprice1.setVisible(true);
            lblmdesc1.setVisible(true);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        } else if (mList.isEmpty()) {
            txtsearch.setText("Sorry no restaurants items available");

            btncart1.setVisible(false);
            lblmname1.setVisible(false);
            lblmprice1.setVisible(false);
            lblmdesc1.setVisible(false);
            lblmname2.setVisible(false);
            lblmprice2.setVisible(false);
            lblmdesc2.setVisible(false);
            lblmname3.setVisible(false);
            lblmprice3.setVisible(false);
            lblmdesc3.setVisible(false);
            btncart2.setVisible(false);
            btnnext.setVisible(false);
            btnprev.setVisible(false);
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel10 = new javax.swing.JPanel();
        jButton18 = new javax.swing.JButton();
        lblrating = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        lblrname = new javax.swing.JLabel();
        jButton19 = new javax.swing.JButton();
        lblrpic = new javax.swing.JLabel();
        lblradd = new javax.swing.JLabel();
        btnnext = new javax.swing.JButton();
        btnprev = new javax.swing.JButton();
        btnn2 = new javax.swing.JButton();
        btnp3 = new javax.swing.JButton();
        btnn3 = new javax.swing.JButton();
        btnn1 = new javax.swing.JButton();
        btnp1 = new javax.swing.JButton();
        btnp2 = new javax.swing.JButton();
        lblmprice1 = new javax.swing.JLabel();
        lblmprice2 = new javax.swing.JLabel();
        lblmprice3 = new javax.swing.JLabel();
        btncart1 = new javax.swing.JButton();
        btncart2 = new javax.swing.JButton();
        btncart3 = new javax.swing.JButton();
        txtsearch = new javax.swing.JTextField();
        btnsearch = new javax.swing.JButton();
        lblmdesc1 = new javax.swing.JLabel();
        lblmname1 = new javax.swing.JLabel();
        lblmdesc2 = new javax.swing.JLabel();
        lblmname2 = new javax.swing.JLabel();
        lblmname3 = new javax.swing.JLabel();
        lblmdesc3 = new javax.swing.JLabel();
        lblmpic2 = new javax.swing.JLabel();
        lblmpic1 = new javax.swing.JLabel();
        lblmpic3 = new javax.swing.JLabel();
        lblq1 = new javax.swing.JLabel();
        lblq2 = new javax.swing.JLabel();
        lblq3 = new javax.swing.JLabel();
        jButton20 = new javax.swing.JButton();
        btnorderhistory = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setPreferredSize(new java.awt.Dimension(800, 600));

        jButton18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton18.setForeground(new java.awt.Color(255, 51, 51));
        jButton18.setText("Reviews");
        jButton18.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton18ActionPerformed(evt);
            }
        });

        lblrating.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblrating.setText("Rating");

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dbms/eat/rating.JPG"))); // NOI18N

        lblrname.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblrname.setForeground(new java.awt.Color(255, 51, 51));
        lblrname.setText("Restaurant name");

        jButton19.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton19.setForeground(new java.awt.Color(255, 51, 51));
        jButton19.setText("Back");
        jButton19.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton19ActionPerformed(evt);
            }
        });

        lblradd.setText("Address");

        btnnext.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnnext.setForeground(new java.awt.Color(255, 51, 51));
        btnnext.setText(">");
        btnnext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnnextActionPerformed(evt);
            }
        });

        btnprev.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnprev.setForeground(new java.awt.Color(255, 51, 51));
        btnprev.setText("<");
        btnprev.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnprevActionPerformed(evt);
            }
        });

        btnn2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnn2.setForeground(new java.awt.Color(255, 51, 51));
        btnn2.setText("-");
        btnn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnn2ActionPerformed(evt);
            }
        });

        btnp3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnp3.setForeground(new java.awt.Color(255, 51, 51));
        btnp3.setText("+");
        btnp3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnp3ActionPerformed(evt);
            }
        });

        btnn3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnn3.setForeground(new java.awt.Color(255, 51, 51));
        btnn3.setText("-");
        btnn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnn3ActionPerformed(evt);
            }
        });

        btnn1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnn1.setForeground(new java.awt.Color(255, 51, 51));
        btnn1.setText("-");
        btnn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnn1ActionPerformed(evt);
            }
        });

        btnp1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnp1.setForeground(new java.awt.Color(255, 51, 51));
        btnp1.setText("+");
        btnp1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnp1ActionPerformed(evt);
            }
        });

        btnp2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnp2.setForeground(new java.awt.Color(255, 51, 51));
        btnp2.setText("+");
        btnp2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnp2ActionPerformed(evt);
            }
        });

        lblmprice1.setText("jLabel3");

        lblmprice2.setText("jLabel3");

        lblmprice3.setText("jLabel3");

        btncart1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btncart1.setForeground(new java.awt.Color(255, 51, 51));
        btncart1.setText("Add to Cart");
        btncart1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncart1ActionPerformed(evt);
            }
        });

        btncart2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btncart2.setForeground(new java.awt.Color(255, 51, 51));
        btncart2.setText("Add to Cart");
        btncart2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncart2ActionPerformed(evt);
            }
        });

        btncart3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btncart3.setForeground(new java.awt.Color(255, 51, 51));
        btncart3.setText("Add to Cart");
        btncart3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btncart3ActionPerformed(evt);
            }
        });

        txtsearch.setFont(new java.awt.Font("Segoe UI", 2, 14)); // NOI18N
        txtsearch.setText("        Search an Item by name.....");
        txtsearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtsearchMouseClicked(evt);
            }
        });
        txtsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtsearchActionPerformed(evt);
            }
        });

        btnsearch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnsearch.setForeground(new java.awt.Color(255, 51, 51));
        btnsearch.setText("SEARCH");
        btnsearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsearchActionPerformed(evt);
            }
        });

        lblmdesc1.setText("jLabel1");

        lblmname1.setText("jLabel4");

        lblmdesc2.setText("jLabel1");

        lblmname2.setText("jLabel4");

        lblmname3.setText("jLabel1");

        lblmdesc3.setText("jLabel4");

        lblq1.setText("0");

        lblq2.setText("0");

        lblq3.setText("0");

        jButton20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dbms/eat/cart.JPG"))); // NOI18N
        jButton20.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton20ActionPerformed(evt);
            }
        });

        btnorderhistory.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btnorderhistory.setForeground(new java.awt.Color(255, 51, 51));
        btnorderhistory.setText("OrderHistory");
        btnorderhistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnorderhistoryActionPerformed(evt);
            }
        });

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/dbms/eat/logo.jpg"))); // NOI18N

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGap(97, 97, 97)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(lblmprice1)
                        .addGap(174, 174, 174)
                        .addComponent(lblmprice2)
                        .addGap(608, 608, 608))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(btnn1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblq1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnp1)
                        .addGap(798, 798, 798))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(153, 153, 153)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblrname)
                            .addComponent(lblradd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnorderhistory)
                            .addComponent(jButton19))
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(80, 80, 80)
                                .addComponent(txtsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 261, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(btnsearch))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(64, 64, 64)
                                .addComponent(lblrpic, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(54, 54, 54)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addGap(20, 20, 20)
                                        .addComponent(jLabel19)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblrating))
                                    .addComponent(jButton18)))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(50, 50, 50)
                                .addComponent(btnprev)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblmpic1, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblmdesc1)
                                    .addComponent(lblmname1)))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(86, 86, 86)
                                .addComponent(btncart1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(53, 53, 53)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addComponent(btnn2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lblq2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnp2))
                                    .addComponent(btncart2))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btncart3)
                                    .addGroup(jPanel10Layout.createSequentialGroup()
                                        .addComponent(btnn3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(lblmprice3)
                                            .addGroup(jPanel10Layout.createSequentialGroup()
                                                .addComponent(lblq3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnp3)))))
                                .addGap(41, 41, 41)
                                .addComponent(jButton20, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblmname2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblmpic2, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(lblmpic3, javax.swing.GroupLayout.DEFAULT_SIZE, 165, Short.MAX_VALUE)
                                    .addComponent(lblmdesc3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(lblmdesc2, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblmname3, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnnext)
                .addGap(227, 227, 227))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(lblrname)))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addComponent(lblradd)
                        .addGap(18, 18, 18)
                        .addComponent(jButton18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(lblrating)))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(btnorderhistory)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton19))
                            .addComponent(lblrpic, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 12, Short.MAX_VALUE)))
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtsearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnsearch, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmpic1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblmpic2, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblmpic3, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnprev)
                    .addComponent(btnnext))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblmname1)
                    .addComponent(lblmname2)
                    .addComponent(lblmdesc3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblmdesc1)
                        .addComponent(lblmdesc2))
                    .addComponent(lblmname3))
                .addGap(34, 34, 34)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblq1)
                            .addComponent(btnn1)
                            .addComponent(btnp1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblmprice1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btncart1))
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblq2)
                            .addComponent(btnn2)
                            .addComponent(btnp2)
                            .addComponent(btnn3)
                            .addComponent(lblq3)
                            .addComponent(btnp3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(lblmprice2)
                            .addComponent(lblmprice3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btncart2)
                            .addComponent(btncart3)))
                    .addComponent(jButton20, javax.swing.GroupLayout.Alignment.TRAILING))
                .addGap(0, 28, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, 935, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 612, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnn2ActionPerformed
        if (Integer.parseInt(lblq2.getText()) > 1) {
            lblq2.setText(String.valueOf(Integer.parseInt(lblq2.getText()) - 1));
            Menu m = mList.get((1));
            lblmprice2.setText(String.valueOf(Double.parseDouble(lblmprice2.getText()) - (m.getiPrice())));
            lblq2.setVisible(true);
        } else if (Integer.parseInt(lblq2.getText()) == 1) {
            lblq2.setVisible(false);
        }
    }//GEN-LAST:event_btnn2ActionPerformed

    private void btnn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnn1ActionPerformed
        if (Integer.parseInt(lblq1.getText()) > 1) {
            lblq1.setText(String.valueOf(Integer.parseInt(lblq1.getText()) - 1));
            Menu m = mList.get((0));
            lblmprice1.setText(String.valueOf(Double.parseDouble(lblmprice1.getText()) - (m.getiPrice())));
            lblq1.setVisible(true);
        } else if (Integer.parseInt(lblq1.getText()) == 1) {
            lblq1.setVisible(false);
        }
    }//GEN-LAST:event_btnn1ActionPerformed

    private void txtsearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtsearchMouseClicked
        if (txtsearch.getText().equals("        Search an Item by name.....")) {
            txtsearch.setText("");
        }
    }//GEN-LAST:event_txtsearchMouseClicked

    private void txtsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtsearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtsearchActionPerformed

    private void jButton19ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton19ActionPerformed
        HomePageGUI hp=new HomePageGUI(u);
    }//GEN-LAST:event_jButton19ActionPerformed

    private void btnsearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsearchActionPerformed
        setInitialVisibility();
        setSearchMenuData();
    }//GEN-LAST:event_btnsearchActionPerformed

    private void jButton18ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton18ActionPerformed
        ReviewsGUI rv = new ReviewsGUI(this, u);
        this.setVisible(false);
        rv.setVisible(true);
    }//GEN-LAST:event_jButton18ActionPerformed

    private void btnnextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnnextActionPerformed
        setInitialVisibility();
        setNextMenuData();
    }//GEN-LAST:event_btnnextActionPerformed

    private void btnp1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnp1ActionPerformed
        lblq1.setText(String.valueOf(Integer.parseInt(lblq1.getText()) + 1));
        Menu m = mList.get((0));
        lblmprice1.setText(String.valueOf(m.getiPrice() * Double.parseDouble(lblq1.getText())));
        lblq1.setVisible(true);
    }//GEN-LAST:event_btnp1ActionPerformed

    private void btnp2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnp2ActionPerformed
        lblq2.setText(String.valueOf(Integer.parseInt(lblq2.getText()) + 1));
        Menu m = mList.get((1));
        lblmprice2.setText(String.valueOf(m.getiPrice() * Double.parseDouble(lblq2.getText())));
        lblq2.setVisible(true);
    }//GEN-LAST:event_btnp2ActionPerformed

    private void btnp3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnp3ActionPerformed
        lblq3.setText(String.valueOf(Integer.parseInt(lblq3.getText()) + 1));
        Menu m = mList.get((2));
        lblmprice3.setText(String.valueOf(m.getiPrice() * Double.parseDouble(lblq3.getText())));
        lblq3.setVisible(true);
    }//GEN-LAST:event_btnp3ActionPerformed

    private void btnn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnn3ActionPerformed
        if (Integer.parseInt(lblq3.getText()) > 1) {
            lblq3.setText(String.valueOf(Integer.parseInt(lblq3.getText()) - 1));
            Menu m = mList.get((2));
            lblmprice3.setText(String.valueOf(Double.parseDouble(lblmprice3.getText()) - (m.getiPrice())));
            lblq3.setVisible(true);
        } else if (Integer.parseInt(lblq3.getText()) == 1) {
            lblq3.setVisible(false);
        }
    }//GEN-LAST:event_btnn3ActionPerformed

    private void btncart1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncart1ActionPerformed

        Menu mobj = new Menu();
        mobj = mList.get(0);
        mobj.setQty(Integer.parseInt(lblq1.getText()));
        mobj.setItemSubTotal(Float.parseFloat(lblmprice1.getText()));
        cartList.add(mobj);
        lblq1.setText("0");
        lblq1.setVisible(false);
        lblmprice1.setText(String.valueOf(mobj.getiPrice()));
        JOptionPane.showMessageDialog(null, "Item added into cart!");
    }//GEN-LAST:event_btncart1ActionPerformed

    private void btncart2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncart2ActionPerformed
        Menu mobj = new Menu();
        mobj = mList.get(1);
        mobj.setQty(Integer.parseInt(lblq2.getText()));
        mobj.setItemSubTotal(Float.parseFloat(lblmprice2.getText()));
        cartList.add(mobj);
        lblq2.setText("0");
        lblq2.setVisible(false);
        lblmprice2.setText(String.valueOf(mobj.getiPrice()));
        JOptionPane.showMessageDialog(null, "Item added into cart!");

    }//GEN-LAST:event_btncart2ActionPerformed

    private void btncart3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btncart3ActionPerformed
        Menu mobj = new Menu();
        mobj = mList.get(2);
        mobj.setQty(Integer.parseInt(lblq3.getText()));
        mobj.setItemSubTotal(Float.parseFloat(lblmprice3.getText()));
        cartList.add(mobj);
        lblq3.setText("0");
        lblq3.setVisible(false);
        lblmprice3.setText(String.valueOf(mobj.getiPrice()));
        JOptionPane.showMessageDialog(null, "Item added into cart!");

    }//GEN-LAST:event_btncart3ActionPerformed

    private void btnprevActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnprevActionPerformed
               setInitialVisibility();
        setPrevMenuData();
    }//GEN-LAST:event_btnprevActionPerformed

    private void jButton20ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton20ActionPerformed
        this.setVisible(false);
        CartGUI cartg = new CartGUI(this,u,r);
        cartg.setVisible(true);
    }//GEN-LAST:event_jButton20ActionPerformed

    private void btnorderhistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnorderhistoryActionPerformed
          oh = new OrderHistoryGUI(this, u);
        this.setVisible(false);
        oh.setVisible(true);
    }//GEN-LAST:event_btnorderhistoryActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RestaurantGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RestaurantGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RestaurantGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RestaurantGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new RestaurantGUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btncart1;
    private javax.swing.JButton btncart2;
    private javax.swing.JButton btncart3;
    private javax.swing.JButton btnn1;
    private javax.swing.JButton btnn2;
    private javax.swing.JButton btnn3;
    private javax.swing.JButton btnnext;
    private javax.swing.JButton btnorderhistory;
    private javax.swing.JButton btnp1;
    private javax.swing.JButton btnp2;
    private javax.swing.JButton btnp3;
    private javax.swing.JButton btnprev;
    private javax.swing.JButton btnsearch;
    private javax.swing.JButton jButton18;
    private javax.swing.JButton jButton19;
    private javax.swing.JButton jButton20;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JLabel lblmdesc1;
    private javax.swing.JLabel lblmdesc2;
    private javax.swing.JLabel lblmdesc3;
    private javax.swing.JLabel lblmname1;
    private javax.swing.JLabel lblmname2;
    private javax.swing.JLabel lblmname3;
    private javax.swing.JLabel lblmpic1;
    private javax.swing.JLabel lblmpic2;
    private javax.swing.JLabel lblmpic3;
    private javax.swing.JLabel lblmprice1;
    private javax.swing.JLabel lblmprice2;
    private javax.swing.JLabel lblmprice3;
    private javax.swing.JLabel lblq1;
    private javax.swing.JLabel lblq2;
    private javax.swing.JLabel lblq3;
    private javax.swing.JLabel lblradd;
    private javax.swing.JLabel lblrating;
    private javax.swing.JLabel lblrname;
    private javax.swing.JLabel lblrpic;
    private javax.swing.JTextField txtsearch;
    // End of variables declaration//GEN-END:variables
}
