/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import dbms.eat.ConnectionToDB;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Adil
 */
public class Restaurant {

    private int rID;
    private String rName, rAddress, rContact, rCity;
    private float rating;
    ConnectionToDB con = new ConnectionToDB();
    Connection connection = con.establishConnection();
    Statement stmt = null;
    PreparedStatement pstmt = null;
    ResultSet res = null;
    ResultSet rs = null;
    ArrayList<String> rList= new ArrayList<>();
    public Restaurant(int rID, String rName, String rAddress, String rContact, String rCity) {
        this.rID = rID;
        this.rName = rName;
        this.rAddress = rAddress;
        this.rContact = rContact;
        this.rCity = rCity;
    }

    public Restaurant() {
    }

    public ArrayList<String> getAvailableCities() {
        try {
            String r;
            stmt = connection.createStatement();
            res = stmt.executeQuery("select * from getAvailableCities");
            while (res.next()) {
                rList.add(res.getString("City"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
        return rList;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    
    
    public int getrID() {
        return rID;
    }

    public void setrID(int rID) {
        this.rID = rID;
    }

    public String getrName() {
        return rName;
    }

    public void setrName(String rName) {
        this.rName = rName;
    }

    public String getrAddress() {
        return rAddress;
    }

    public void setrAddress(String rAddress) {
        this.rAddress = rAddress;
    }

    public String getrContact() {
        return rContact;
    }

    public void setrContact(String rContact) {
        this.rContact = rContact;
    }

    public String getrCity() {
        return rCity;
    }

    public void setrCity(String rCity) {
        this.rCity = rCity;
    }

}
