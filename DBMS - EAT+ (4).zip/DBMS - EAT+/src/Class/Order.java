/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import java.sql.*;
import java.text.SimpleDateFormat;

public class Order {

    private int OrderID, Quantity;
    private float TotalAmount, ItemPrice, Discount, ItemSubTotal, OrderSubTtotal,Total;
    private String OrderDate, StatusName;
    private String CustomerName, PhoneNo, DeliveryAddress, RestaurantName, RestaurantAddress, MenuItem, CouponCode, PaymentMethod;
    private String RiderName, LicensePlate;


    public Order() {
    }

    public Order(int OrderID, float ItemPrice, float Discount, float ItemSubTotal, float OrderSubTtotal, float Total, String CustomerName, String PhoneNo, String DeliveryAddress, String RestaurantName, String RestaurantAddress, String MenuItem, String CouponCode, String PaymentMethod) {
        this.OrderID = OrderID;
        this.ItemPrice = ItemPrice;
        this.Discount = Discount;
        this.ItemSubTotal = ItemSubTotal;
        this.OrderSubTtotal = OrderSubTtotal;
        this.Total = Total;
        this.CustomerName = CustomerName;
        this.PhoneNo = PhoneNo;
        this.DeliveryAddress = DeliveryAddress;
        this.RestaurantName = RestaurantName;
        this.RestaurantAddress = RestaurantAddress;
        this.MenuItem = MenuItem;
        this.CouponCode = CouponCode;
        this.PaymentMethod = PaymentMethod;
    }
    
        public Order(int OrderID, String RiderName, String LicensePlate, float ItemPrice, float Discount, float ItemSubTotal, float OrderSubTtotal, float Total, String PhoneNo, String DeliveryAddress, String RestaurantName, String RestaurantAddress, String MenuItem, String CouponCode, String PaymentMethod) {
        this.OrderID = OrderID;
        this.ItemPrice = ItemPrice;
        this.Discount = Discount;
        this.ItemSubTotal = ItemSubTotal;
        this.OrderSubTtotal = OrderSubTtotal;
        this.Total = Total;
        this.RiderName = RiderName;
        this.PhoneNo = PhoneNo;
        this.DeliveryAddress = DeliveryAddress;
        this.RestaurantName = RestaurantName;
        this.RestaurantAddress = RestaurantAddress;
        this.MenuItem = MenuItem;
        this.CouponCode = CouponCode;
        this.PaymentMethod = PaymentMethod;
        this.LicensePlate=LicensePlate;
    }

    public String getLicensePlate() {
        return LicensePlate;
    }

    public void setLicensePlate(String LicensePlate) {
        this.LicensePlate = LicensePlate;
    }

        
        
    public int getQuantity() {
        return Quantity;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public float getItemPrice() {
        return ItemPrice;
    }

    public void setItemPrice(float ItemPrice) {
        this.ItemPrice = ItemPrice;
    }

    public float getDiscount() {
        return Discount;
    }

    public void setDiscount(float Discount) {
        this.Discount = Discount;
    }
        public String getRiderName() {
        return RiderName;
    }

    public void setRiderName(String RiderName) {
        this.RiderName = RiderName;
    }
    public float getItemSubTotal() {
        return ItemSubTotal;
    }

    public void setItemSubTotal(float ItemSubTotal) {
        this.ItemSubTotal = ItemSubTotal;
    }

    public float getOrderSubTtotal() {
        return OrderSubTtotal;
    }

    public void setOrderSubTtotal(float OrderSubTtotal) {
        this.OrderSubTtotal = OrderSubTtotal;
    }

    public float getTotal() {
        return Total;
    }

    public void setTotal(float Total) {
        this.Total = Total;
    }

    public String getCustomerName() {
        return CustomerName;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String PhoneNo) {
        this.PhoneNo = PhoneNo;
    }

    public String getDeliveryAddress() {
        return DeliveryAddress;
    }

    public void setDeliveryAddress(String DeliveryAddress) {
        this.DeliveryAddress = DeliveryAddress;
    }

    public String getRestaurantName() {
        return RestaurantName;
    }

    public void setRestaurantName(String RestaurantName) {
        this.RestaurantName = RestaurantName;
    }

    public String getRestaurantAddress() {
        return RestaurantAddress;
    }

    public void setRestaurantAddress(String RestaurantAddress) {
        this.RestaurantAddress = RestaurantAddress;
    }

    public String getMenuItem() {
        return MenuItem;
    }

    public void setMenuItem(String MenuItem) {
        this.MenuItem = MenuItem;
    }

    public String getCouponCode() {
        return CouponCode;
    }

    public void setCouponCode(String CouponCode) {
        this.CouponCode = CouponCode;
    }

    public String getPaymentMethod() {
        return PaymentMethod;
    }

    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }

    
    
    public Order(int OrderID, float TotalAmount, String OrderDate, String StatusName) {
        this.OrderID = OrderID;
        this.TotalAmount = TotalAmount;
        this.OrderDate = OrderDate;
        this.StatusName = StatusName;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int OrderID) {
        this.OrderID = OrderID;
    }

    public float getTotalAmount() {
        return TotalAmount;
    }

    public void setTotalAmount(float TotalAmount) {
        this.TotalAmount = TotalAmount;
    }

    public String getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(String OrderDate) {
        this.OrderDate = OrderDate;
    }

    public String getStatusName() {
        return StatusName;
    }

    public void setStatusName(String StatusName) {
        this.StatusName = StatusName;
    }

}


//OrderID	TotalAmount	OrderDate	StatusName
