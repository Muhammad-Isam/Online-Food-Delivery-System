/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import dbms.eat.ConnectionToDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Adil
 */
public class Coupon {
    private float cDiscount;
    private String cCode, cExpDate;
        ConnectionToDB con = new ConnectionToDB();
    Connection connection = con.establishConnection();
    Statement stmt = null;
    PreparedStatement pstmt = null;
    ResultSet res = null;
    ResultSet rs = null;

    public Coupon(float cDiscount, String cCode, String cExpDate) {
        this.cDiscount = cDiscount;
        this.cCode = cCode;
        this.cExpDate = cExpDate;
    }

    public Coupon() {
    }

    public float getcDiscount() {
        return cDiscount;
    }

    public void setcDiscount(float cDiscount) {
        this.cDiscount = cDiscount;
    }

    public String getcCode() {
        return cCode;
    }

    public void setcCode(String cCode) {
        this.cCode = cCode;
    }

    public String getcExpDate() {
        return cExpDate;
    }

    public void setcExpDate(String cExpDate) {
        this.cExpDate = cExpDate;
    } 

    @Override
    public String toString() {
        return this.cCode+" "+this.cDiscount+" "+this.cExpDate;
    }
    
}
