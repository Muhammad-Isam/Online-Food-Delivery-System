/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

/**
 *
 * @author dell
 */
public class Review {
    private String comment, customerName, restaurantName, revDate;
    private int rating;

    public Review() {
    }
    
    
    public Review(String comment, String customerName, String restaurantName, String revDate, int rating) {
        this.comment = comment;
        this.customerName = customerName;
        this.restaurantName = restaurantName;
        this.revDate = revDate;
        this.rating=rating;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
    
    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getRestaurantName() {
        return restaurantName;
    }

    public void setRestaurantName(String restaurantName) {
        this.restaurantName = restaurantName;
    }

    public String getRevDate() {
        return revDate;
    }

    public void setRevDate(String revDate) {
        this.revDate = revDate;
    }

    @Override
    public String toString() {
        return  comment + customerName + restaurantName + revDate +  rating;
    }
    
}
