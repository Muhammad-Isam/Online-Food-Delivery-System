/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import dbms.eat.ConnectionToDB;
import java.awt.MenuItem;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.sql.Date;
import java.text.SimpleDateFormat;

/**
 *
 * @author Adil
 */
public class User {

    private String uName, uPassword, uEmail, uPhoneNo, uDOB, uRegDate, uAddress;
    ArrayList<String> uAddressList = new ArrayList<>();
    ConnectionToDB con = new ConnectionToDB();
    Connection connection = con.establishConnection();
    Statement stmt = null;
    PreparedStatement pstmt = null;
    ResultSet res = null;
    ResultSet rs = null;

    public User(String uName, String uPassword, String uEmail, String uPhoneNo, String uDOB, String uRegDate, String uAddress) {
        this.uName = uName;
        this.uPassword = uPassword;
        this.uEmail = uEmail;
        this.uPhoneNo = uPhoneNo;
        this.uDOB = uDOB;
        this.uRegDate = uRegDate;
        this.uAddress = uAddress;
    }

    public User(String uName, String uEmail, ArrayList<String> uAddressList) {
        this.uName = uName;
        this.uEmail = uEmail;
        this.uAddressList = uAddressList;
    }

    public ArrayList<Coupon> getUserCoupon(String Email) {
        ArrayList<Coupon> cList = new ArrayList<>();
        try {
            String sqlQuery = "SELECT * FROM dbo.getUserCoupons(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Coupon c = new Coupon();

                    c.setcCode(res.getString("CouponCode"));
                    c.setcDiscount(res.getFloat("Discount"));
                    c.setcExpDate(res.getString("ExpiryDate"));
                    cList.add(c);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return cList;
    }

    public int getResID(String RName, String RAdd) {
        int rID = 0;
        String sqlQuery = "{? = call getRestaurantID(?, ?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            callableStatement.registerOutParameter(1, Types.VARCHAR);

            // Set input parameters
            callableStatement.setString(2, RName);
            callableStatement.setString(3, RAdd);

            // Execute the stored procedure
            callableStatement.execute();

            // Retrieve the result from the output parameter
            rID = callableStatement.getInt(1);

        } catch (Exception e) {
            System.out.println(e);
        }
        return rID;
    }

    public ArrayList<Menu> getRestaurantMenu(String rName, String rAddr) {
        ArrayList<Menu> mList = new ArrayList<>();
        String sqlQuery = "SELECT * FROM getRestaurantMenu(?,?)";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, rAddr);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Menu m = new Menu();
                    m.setiName(res.getString("Name"));
                    m.setiDescription(res.getString("Description"));
                    m.setiPrice(res.getFloat("Price"));
//                    System.out.println(m.getiName() + m.getiDescription() + m.getiPrice());
                    mList.add(m);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return mList;
    }

    public ArrayList<Menu> getnextRestaurantMenu(String mName, String rName, String rAddr) {
        ArrayList<Menu> mList = new ArrayList<>();
        String sqlQuery = "SELECT * FROM getnextRestaurantMenu(?,?,?)";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, mName);
            callableStatement.setString(2, rName);
            callableStatement.setString(3, rAddr);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Menu m = new Menu();
                    m.setiName(res.getString("Name"));
                    m.setiDescription(res.getString("Description"));
                    m.setiPrice(res.getFloat("Price"));
//                    System.out.println(m.getiName() + m.getiDescription() + m.getiPrice());
                    mList.add(m);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return mList;
    }

    public ArrayList<Menu> searchItem(String mName, String rName, String rAddr) {
        ArrayList<Menu> mList = new ArrayList<>();
        String sqlQuery = "SELECT * FROM searchItem(?,?,?)";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, rAddr);
            callableStatement.setString(3, mName);

            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Menu m = new Menu();
                    m.setiName(res.getString("Name"));
                    m.setiDescription(res.getString("Description"));
                    m.setiPrice(res.getFloat("Price"));
//                    System.out.println(m.getiName() + m.getiDescription() + m.getiPrice());
                    mList.add(m);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return mList;
    }

    public ArrayList<Menu> getprevRestaurantMenu(String mName, String rName, String rAddr) {
        ArrayList<Menu> mList = new ArrayList<>();
        String sqlQuery = "SELECT * FROM getprevRestaurantMenu(?,?,?)";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, mName);
            callableStatement.setString(2, rName);
            callableStatement.setString(3, rAddr);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Menu m = new Menu();
                    m.setiName(res.getString("Name"));
                    m.setiDescription(res.getString("Description"));
                    m.setiPrice(res.getFloat("Price"));
//                    System.out.println(m.getiName() + m.getiDescription() + m.getiPrice());
                    mList.add(m);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return mList;
    }

    public int getLastOrder() {
        int oID = 0;
        String sqlQuery = "SELECT dbo.getLastOrder() AS LastOrderID"; // Assuming dbo is the schema, modify it if needed
        try {
            Statement statement = connection.createStatement();

            // Execute the SELECT statement
            ResultSet resultSet = statement.executeQuery(sqlQuery);

            // Check if there are results
            if (resultSet.next()) {
                oID = resultSet.getInt("LastOrderID");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return oID;
    }

    public double getRestaurantRating(String rName, String rAdd) {
        double rRating = 0;
        String sqlQuery = "SELECT dbo.getRestaurantRating(?,?) AS Rating"; // Assuming dbo is the schema, modify it if needed
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                if (res.next()) {
                    rRating = (res.getDouble("Rating"));
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return rRating;
    }

    public ArrayList<Review> viewRestaurantReviews(String rName) {
        ArrayList<Review> reviewList = new ArrayList<>();

        try {
            String sqlQuery = "SELECT * FROM dbo.RestaurantReview(?)";

            try ( PreparedStatement preparedStatement = connection.prepareStatement(sqlQuery)) {
                preparedStatement.setString(1, rName);

                ResultSet resultSet = preparedStatement.executeQuery();

                while (resultSet.next()) {
                    int rating = resultSet.getInt("Rating");
                    String comment = resultSet.getString("Comment");
                    String revDate = resultSet.getString("RevDate");
                    String customerName = resultSet.getString("Name");

                    Review review = new Review(comment, customerName, rName, revDate, rating);
                    reviewList.add(review);
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        return reviewList;
    }

    public void submitReview(String email, int orderID, int rating, String comment) {
        String sql = "{call submitReview(?, ?, ?, ?, ?)}";
        ArrayList<Order> oL = new ArrayList<>();
        Order o = new Order();
        oL = getUserOrderInfo(orderID);
        o = oL.get(0);
        String RName = o.getRestaurantName();
        String RAdd = o.getRestaurantAddress();
        int resID = getResID(RName, RAdd);

        try {
            CallableStatement callableStatement = connection.prepareCall(sql);

            callableStatement.setString(1, email);
            callableStatement.setInt(2, resID);
            callableStatement.setInt(3, orderID);
            callableStatement.setInt(4, rating);
            callableStatement.setString(5, comment);
            System.out.println(email + resID + orderID + rating + comment);
            // Execute the stored procedure
            callableStatement.execute();

        } catch (Exception e) {

        }
    }

    public void addUserAddress(String Email, String Address) {
        try {
            // Call the stored procedure
            String storedProcedureCall = "{call addUserAddress(?, ?)}";
            CallableStatement callableStatement = connection.prepareCall(storedProcedureCall);

            // Set input parameters
            callableStatement.setString(1, Email);
            callableStatement.setString(2, Address);

            // Execute the stored procedure
            callableStatement.execute();

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void confirmCartOrder(String address, String rName, String rAdd, String uEmail, String PaymentMethod) {
        String sqlQuery = "{call confirmCartOrder(?,?,?,?,?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            // Set input parameters
            callableStatement.setString(1, address);
            callableStatement.setString(2, rName);
            callableStatement.setString(3, rAdd);
            callableStatement.setString(4, uEmail);
            callableStatement.setString(5, PaymentMethod);

            // Execute the stored procedure
            callableStatement.execute();
            System.out.println("all good");
            // No need to retrieve output parameters for this example
            JOptionPane.showMessageDialog(null, "Order Placed!");
        } catch (Exception e) {
            System.out.println(e); // Rethrow the exception for the calling method to handle
        }
    }

    public void placeOrder(String code) {
        String sqlQuery = "{call placeOrder(?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            // Set input parameters
            callableStatement.setString(1, code);

            // Execute the stored procedure
            callableStatement.execute();
            System.out.println("works");
            // No need to retrieve output parameters for this example
        } catch (Exception e) {
            System.out.println(e); // Rethrow the exception for the calling method to handle
        }
    }

    public void placeItemOrder(String mName, Float price, int Qty, Float subTotal) {
        String sqlQuery = "{call placeItemOrder(?,?,?,?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            // Set input parameters
            callableStatement.setString(1, mName);
            callableStatement.setFloat(2, price);
            callableStatement.setInt(3, Qty);
            callableStatement.setFloat(4, subTotal);

            // Execute the stored procedure
            callableStatement.execute();
            System.out.println("works here");
            // No need to retrieve output parameters for this example
        } catch (Exception e) {
            System.out.println(e); // Rethrow the exception for the calling method to handle
        }
    }

    public User signUpUser(String name, String email, String password, String phoneNo,
            String address, String city, String dob) {
        ArrayList<String> uList = new ArrayList<>();
        uList.add(address);
        User u = new User();

        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            java.util.Date parsedDate = sdf.parse(dob);
            Date sqlDate = new Date(parsedDate.getTime());
            u.setuName(name);
            u.setuEmail(email);
            u.setuPhoneNo(uPhoneNo);
            // Call the stored procedure
            String storedProcedureCall = "{call CustomerSignUp(?, ?, ?, ?, ?, ?, ?)}";
            CallableStatement callableStatement = connection.prepareCall(storedProcedureCall);

            // Set input parameters
            callableStatement.setString(1, name);
            callableStatement.setString(2, email);
            callableStatement.setString(3, password);
            callableStatement.setString(4, phoneNo);
            callableStatement.setString(5, address);
            callableStatement.setString(6, city);
            callableStatement.setDate(7, sqlDate);
            System.out.println(name + email + password + phoneNo + address + city + sqlDate);
            // Execute the stored procedure
            callableStatement.execute();

            // No need to retrieve output parameters for this example
        } catch (Exception e) {
            System.out.println(e); // Rethrow the exception for the calling method to handle
        }
        JOptionPane.showMessageDialog(null, "Sign up successful!");

        return u;
    }

    public ArrayList<Order> riderOrders(String Email) {
        ArrayList<Order> oList = new ArrayList<>();
        Order o = new Order();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM dbo.riderOrders(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    o.setOrderID(res.getInt("OrderID"));
                    o.setTotalAmount(res.getFloat("TotalAmount"));
                    o.setOrderDate(res.getString("OrderDate"));
                    o.setStatusName(res.getString("StatusName"));
                    oList.add(o);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return oList;
    }

    public ArrayList<Restaurant> getRestaurants() {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "select * from getRestaurants";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getRestaurantByName(String rName) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM getRestaurantByName(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getNextRestaurants(String rName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM nextRestaurants(?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getPrevRestaurants(String rName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM prevRestaurants(?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> searchRestaurantbyCity(String City) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM searchRestaurantbyCity(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, City);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> nextSearchRestByCity(String City, String rName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM nextSearchRestByCity(?,?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, City);
            callableStatement.setString(2, rName);
            callableStatement.setString(3, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> prevSearchRestByCity(String City, String rName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM prevSearchRestByCity(?,?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, City);
            callableStatement.setString(2, rName);
            callableStatement.setString(3, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<String> getCategories() {
        ArrayList<String> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "select * from getCategory";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    rList.add(res.getString("CategoryType"));
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<String> getNextCategory(String Cat) {
        ArrayList<String> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM nextCategory(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Cat);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    rList.add(res.getString("CategoryType"));
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<String> getPrevCategory(String Cat) {
        ArrayList<String> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM prevCategory(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Cat);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    rList.add(res.getString("CategoryType"));
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getTopPicks() {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "select * from TopPicks";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    r.setRating(res.getFloat("Rating"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getRestByCatCity(String City, String Cat) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM getRestByCatCity(?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, City);
            callableStatement.setString(2, Cat);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getNextResByCatCity(String City, String Cat, String rName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM getNextResByCatCity(?,?,?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, City);
            callableStatement.setString(2, Cat);
            callableStatement.setString(3, rName);
            callableStatement.setString(4, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getPrevResByCatCity(String City, String Cat, String rName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM getPrevResByCatCity(?,?,?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, City);
            callableStatement.setString(2, Cat);
            callableStatement.setString(3, rName);
            callableStatement.setString(4, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getnextRestaurantByName(String rName, String resName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM nextRestaurantByName(?,?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, resName);
            callableStatement.setString(3, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Restaurant> getPrevRestaurantByName(String rName, String resName, String rAdd) {
        ArrayList<Restaurant> rList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM prevRestaurantByName(?,?,?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, rName);
            callableStatement.setString(2, resName);
            callableStatement.setString(3, rAdd);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Restaurant r = new Restaurant();
                    r.setrName(res.getString("Name"));
                    r.setrAddress(res.getString("Address"));
                    rList.add(r);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return rList;
    }

    public ArrayList<Order> userOrders(String Email) {
        ArrayList<Order> oList = new ArrayList<>();
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM dbo.showUserOrders(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Order o = new Order();
                    o.setOrderID(res.getInt("OrderID"));
                    o.setTotalAmount(res.getFloat("TotalAmount"));
                    o.setOrderDate(res.getString("OrderDate"));
                    oList.add(o);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return oList;
    }

    public ArrayList<Order> getRiderOrderInfo(int orderID) {
        ArrayList<Order> oList = new ArrayList<>();
        try {
            // Execute the query
            String sqlQuery = "SELECT * FROM dbo.getRiderOrderInfo(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setInt(1, orderID);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Order o = new Order(); // Create a new Order object for each row
                    o.setOrderID(res.getInt("OrderID"));
                    o.setQuantity(res.getInt("Quantity"));
                    o.setCouponCode(res.getString("CouponCode"));
                    o.setDeliveryAddress(res.getString("DeliveryAddress"));
                    o.setDiscount(res.getFloat("Discount"));
                    o.setItemPrice(res.getFloat("ItemPrice"));
                    o.setItemSubTotal(res.getFloat("ItemSubTotal"));
                    o.setMenuItem(res.getString("Menu Item"));
                    o.setOrderSubTtotal(res.getFloat("OrderSubTotal"));
                    o.setPaymentMethod(res.getString("PaymentMethod"));
                    o.setPhoneNo(res.getString("PhoneNo"));
                    o.setRestaurantName(res.getString("RestaurantName"));
                    o.setRestaurantAddress(res.getString("RestaurantAddress"));
                    o.setTotal(res.getFloat("Total"));
                    o.setCustomerName(res.getString("CustomerName"));

                    oList.add(o);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return oList;
    }

    public ArrayList<Order> getUserOrderInfo(int orderID) {
        ArrayList<Order> oList = new ArrayList<>();
        try {
            // Execute the query
            String sqlQuery = "SELECT * FROM dbo.getUserOrderInfo(?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setInt(1, orderID);
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    Order o = new Order(); // Create a new Order object for each row
                    o.setOrderID(res.getInt("OrderID"));
                    o.setQuantity(res.getInt("Quantity"));
                    o.setCouponCode(res.getString("CouponCode"));
                    o.setDeliveryAddress(res.getString("DeliveryAddress"));
                    o.setDiscount(res.getFloat("Discount"));
                    o.setItemPrice(res.getFloat("ItemPrice"));
                    o.setItemSubTotal(res.getFloat("ItemSubTotal"));
                    o.setMenuItem(res.getString("Menu Item"));
                    o.setOrderSubTtotal(res.getFloat("OrderSubTotal"));
                    o.setPaymentMethod(res.getString("PaymentMethod"));
                    o.setPhoneNo(res.getString("Phone"));
                    o.setLicensePlate(res.getString("LicensePlate"));
                    o.setRestaurantName(res.getString("RestaurantName"));
                    o.setRestaurantAddress(res.getString("RestaurantAddress"));
                    o.setTotal(res.getFloat("Total"));
                    o.setRiderName(res.getString("RiderName"));

                    oList.add(o);
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        return oList;
    }

    public User getUserDetail(String Email, String Password) {
        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM dbo.getUserDetail(?, ?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);
            callableStatement.setString(2, Password);

            // Execute the query and retrieve the result set
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                if (res.next()) {
                    setuName(res.getString("Name"));
                    setuEmail(res.getString("Email"));
                    setuPassword(res.getString("Password"));
                    setuPhoneNo(res.getString("PhoneNo"));
                    System.out.println(getuName() + getuEmail());
                }
            }

            // Execute the second query (assuming UserAddress is a table-valued function)
            sqlQuery = "SELECT dbo.getUserAddress(?) AS 'Address'";
            callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);

            // Execute the query and retrieve the result set
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                if (res.next()) {

                    setuAddress(res.getString("Address"));
                    uAddressList.add(res.getString("Address"));
                    System.out.println(res.getString("Address"));
                }
            }

            // Execute the third query (assuming UserAddressNotDefault is a table-valued function)
            sqlQuery = "SELECT * FROM dbo.getUserAddressNotDefault(?)";
            callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);

            // Execute the query and retrieve the result set
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                while (res.next()) {
                    uAddressList.add(res.getString("Address"));
                    System.out.println(res.getString("Address"));
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        // Continue processing as needed
        return this;
    }

    public String loginUser(String Email, String Password) {
        String result = "";
        String sqlQuery = "{? = call loginUser(?, ?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            callableStatement.registerOutParameter(1, Types.VARCHAR);

            // Set input parameters
            callableStatement.setString(2, Email);
            callableStatement.setString(3, Password);

            // Execute the stored procedure
            callableStatement.execute();

            // Retrieve the result from the output parameter
            result = callableStatement.getString(1);

        } catch (Exception e) {
            System.out.println(e);
        }
        return result;
    }

    public String checkReviewEligibility(String Email, int orderID) {
        String result = "";
        String sqlQuery = "{? = call checkReviewEligibility(?, ?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            callableStatement.registerOutParameter(1, Types.VARCHAR);

            // Set input parameters
            callableStatement.setString(2, Email);
            callableStatement.setInt(3, orderID);

            // Execute the stored procedure
            callableStatement.execute();

            // Retrieve the result from the output parameter
            result = callableStatement.getString(1);

        } catch (Exception e) {
            System.out.println(e);
        }
        return result;
    }

    public String deliverRiderOrder(int orderID) {
        String message = "";

        try {
            // Call the stored procedure
            String storedProcedureCall = "{call riderDeliverOrder(?, ?)}";
            CallableStatement callableStatement = connection.prepareCall(storedProcedureCall);

            // Set input parameters
            callableStatement.setInt(1, orderID);

            // Register the output parameter
            callableStatement.registerOutParameter(2, Types.VARCHAR);

            // Execute the stored procedure
            callableStatement.execute();

            // Retrieve the output parameter
            message = callableStatement.getString(2);
            JOptionPane.showMessageDialog(null, "Delivered!");

        } catch (Exception e) {
            System.out.println(e); // Handle the exception appropriately
        }

        return message;
    }

    public User getRiderDetail(String Email, String Password) {
        User uobj = new User();

        try {
            // Execute the first query (assuming getUserDetail is a table-valued function)
            String sqlQuery = "SELECT * FROM dbo.getRiderDetail(?, ?)";
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);
            callableStatement.setString(1, Email);
            callableStatement.setString(2, Password);

            // Execute the query and retrieve the result set
            if (callableStatement.execute()) {
                res = callableStatement.getResultSet();
                if (res.next()) {
                    uobj.setuName(res.getString("FirstName"));
                    uobj.setuName(uobj.getuName() + " " + res.getString("LastName"));
                    uobj.setuEmail(res.getString("Email"));
                    uobj.setuPhoneNo(res.getString("Phone"));
                    System.out.println(uobj.getuName() + uobj.getuEmail());
                    System.out.println(uobj.getuName() + uobj.getuEmail() + uobj.getuPhoneNo());
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        // Continue processing as needed
        return uobj;
    }

    public String loginRider(String Email, String Password) {
        String result = "";
        String sqlQuery = "{? = call loginRider(?, ?)}";
        try {
            CallableStatement callableStatement = connection.prepareCall(sqlQuery);

            callableStatement.registerOutParameter(1, Types.VARCHAR);

            // Set input parameters
            callableStatement.setString(2, Email);
            callableStatement.setString(3, Password);

            // Execute the stored procedure
            callableStatement.execute();

            // Retrieve the result from the output parameter
            result = callableStatement.getString(1);

        } catch (Exception e) {
            System.out.println(e);
        }
        return result;
    }

    public ArrayList<String> getuAddressList() {
        return uAddressList;
    }

    public void setuAddressList(ArrayList<String> uAddressList) {
        this.uAddressList = uAddressList;
    }

    @Override
    public String toString() {
        return "User{" + "uName=" + uName + ", uEmail=" + uEmail + ", uAddressList=" + uAddressList + '}';
    }

    public User() {
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getuPassword() {
        return uPassword;
    }

    public void setuPassword(String uPassword) {
        this.uPassword = uPassword;
    }

    public String getuEmail() {
        return uEmail;
    }

    public void setuEmail(String uEmail) {
        this.uEmail = uEmail;
    }

    public String getuPhoneNo() {
        return uPhoneNo;
    }

    public void setuPhoneNo(String uPhoneNo) {
        this.uPhoneNo = uPhoneNo;
    }

    public String getuDOB() {
        return uDOB;
    }

    public void setuDOB(String uDOB) {
        this.uDOB = uDOB;
    }

    public String getuRegDate() {
        return uRegDate;
    }

    public void setuRegDate(String uRegDate) {
        this.uRegDate = uRegDate;
    }

    public String getuAddress() {
        return uAddress;
    }

    public void setuAddress(String uAddress) {
        this.uAddress = uAddress;
    }

}
