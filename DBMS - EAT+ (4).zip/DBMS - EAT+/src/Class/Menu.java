/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Class;

import dbms.eat.ConnectionToDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

/**
 *
 * @author Adil
 */
public class Menu {
    private int itemID, qty;
    private float iPrice, itemSubTotal;
    private String iName, iDescription;
        ConnectionToDB con = new ConnectionToDB();
    Connection connection = con.establishConnection();
    Statement stmt = null;
    PreparedStatement pstmt = null;
    ResultSet res = null;
    ResultSet rs = null;

    public Menu(int itemID, float iPrice, String iName, String iDescription) {
        this.itemID = itemID;
        this.iPrice = iPrice;
        this.iName = iName;
        this.iDescription = iDescription;
    }

    public Menu() {
    }

    public float getItemSubTotal() {
        return itemSubTotal;
    }

    public void setItemSubTotal(float itemSubTotal) {
        this.itemSubTotal = itemSubTotal;
    }
    
    
    
    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }
    
    
    
    public int getItemID() {
        return itemID;
    }

    public void setItemID(int itemID) {
        this.itemID = itemID;
    }

    public float getiPrice() {
        return iPrice;
    }

    public void setiPrice(float iPrice) {
        this.iPrice = iPrice;
    }

    public String getiName() {
        return iName;
    }

    public void setiName(String iName) {
        this.iName = iName;
    }

    public String getiDescription() {
        return iDescription;
    }

    public void setiDescription(String iDescription) {
        this.iDescription = iDescription;
    }    
}
